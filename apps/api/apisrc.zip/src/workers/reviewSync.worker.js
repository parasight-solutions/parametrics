import { Worker } from 'bullmq'
import { connection } from '../lib/queues.js'

new Worker('review-sync', async job => {
  const { locationId, since } = job.data
  // TODO: pull reviews from Google GBP and upsert
  return { ok: true, locationId, since }
}, { connection })
