// apps/api/src/integrations/google.store.js
import { randomUUID } from 'crypto';
import { col } from '../lib/mongo.js';
import { encJson, decJson } from '../lib/crypto.js';

const COLLECTION = 'integrations';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const nowSec = () => Math.floor(Date.now() / 1000);

function assertAesKey() {
  const k = process.env.APP_AES_KEY || '';
  if (k.length !== 64) {
    const e = new Error('APP_AES_KEY_missing_or_invalid');
    e.hint = 'Set a 64-char hex string in apps/api/.env and restart.';
    throw e;
  }
}

async function fetchJson(url, opts = {}) {
  const r = await fetch(url, opts);
  const text = await r.text();
  const body = text ? (() => { try { return JSON.parse(text) } catch { return { raw: text } } })() : {};
  if (!r.ok) {
    const err = new Error('http_error');
    err.status = r.status; err.body = body;
    throw err;
  }
  return body;
}

// ----- Core find/upsert/update -----

export async function getGoogleIntegration(userId) {
  const c = await col(COLLECTION);
  return c.findOne({ user_id: userId, provider: 'google', active: { $ne: false } });
}

export async function getActiveGoogleIntegration(userId) {
  return getGoogleIntegration(userId);
}

export async function upsertGoogleIntegration(userId, doc) {
  const c = await col(COLLECTION);
  const now = new Date();
  const existing = await c.findOne({ user_id: userId, provider: 'google' });

  if (existing) {
    const { value } = await c.findOneAndUpdate(
      { id: existing.id },
      { $set: { ...doc, active: true, updated_at: now } },
      { returnDocument: 'after' }
    );
    return value;
  }

  const toInsert = {
    id: randomUUID(),
    user_id: userId,
    provider: 'google',
    scopes: [],
    active: true,
    created_at: now,
    updated_at: now,
    ...doc,
  };
  await c.insertOne(toInsert);
  return toInsert;
}

export async function updateGoogleIntegration(id, patch) {
  const c = await col(COLLECTION);
  const now = new Date();
  const { value } = await c.findOneAndUpdate(
    { id },
    { $set: { ...patch, updated_at: now } },
    { returnDocument: 'after' }
  );
  return value;
}

// Back-compat alias
export const saveGoogleIntegration = upsertGoogleIntegration;

// ----- Token access/refresh (works with either a doc or userId) -----

export async function ensureAccessToken(integOrUserId) {
  assertAesKey();

  let integ = null;
  if (typeof integOrUserId === 'string') {
    // treat argument as userId
    integ = await getGoogleIntegration(integOrUserId);
  } else if (integOrUserId && typeof integOrUserId === 'object') {
    // treat argument as an integration doc
    integ = integOrUserId;
  }

  if (!integ) {
    const e = new Error('no_integration'); e.code = 'no_integration'; throw e;
  }

  const client_id = process.env.GOOGLE_CLIENT_ID;
  const client_secret = process.env.GOOGLE_CLIENT_SECRET;
  if (!client_id || !client_secret) {
    const e = new Error('config_missing_client');
    e.hint = 'Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in apps/api/.env';
    throw e;
  }

  let secrets = {};
  try {
    secrets = decJson(integ.secrets_json || '{}'); // tolerate empty on first save
  } catch (err) {
    err.code = 'decrypt_failed';
    err.hint = 'Check APP_AES_KEY matches the key used to encrypt existing secrets.';
    throw err;
  }

  const exp = Number(secrets.expiry_date || 0);

  // still valid
  if (secrets.access_token && exp > nowSec() + 60) {
    return { access_token: secrets.access_token };
  }

  if (!secrets.refresh_token) {
    const e = new Error('no_refresh_token');
    e.hint = 'Remove app access from your Google Account and reconnect (prompt=consent).';
    throw e;
  }

  const form = new URLSearchParams({
    client_id,
    client_secret,
    grant_type: 'refresh_token',
    refresh_token: secrets.refresh_token,
  });

  const tok = await fetchJson(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form.toString(),
  });

  const updated = {
    access_token: tok.access_token,
    refresh_token: secrets.refresh_token,
    expiry_date: nowSec() + Number(tok.expires_in || 3600),
    scope: tok.scope || secrets.scope,
    token_type: tok.token_type || 'Bearer',
  };

  // IMPORTANT: preserve previously stored fields like email/sub/id_token if present
  const merged = { ...secrets, ...updated };

  await updateGoogleIntegration(integ.id, { secrets_json: encJson(merged) });
  return { access_token: merged.access_token };
}
