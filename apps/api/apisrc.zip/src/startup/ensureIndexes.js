// apps/api/src/startup/ensureIndexes.js
import { col } from '../lib/mongo.js'

const keyEq = (a, b) => JSON.stringify(a) === JSON.stringify(b)

async function listIdx(c) {
  return c.listIndexes().toArray()
}

async function dropIndexIfExists(c, name) {
  try {
    await c.dropIndex(name)
    console.log('[indexes] dropped', c.collectionName, name)
  } catch (e) {
    // NamespaceNotFound / IndexNotFound etc → ignore
  }
}

/**
 * Ensure an index exists without crashing if:
 * - same key exists under a different name
 * - same name exists but wrong key (we drop + recreate)
 */
async function ensureIndex(c, key, opts = {}) {
  const existing = await listIdx(c)

  // If an index with identical key already exists, just accept it (avoid name conflicts).
  const sameKey = existing.find(ix => keyEq(ix.key, key))
  if (sameKey) {
    // If uniqueness differs, we must recreate (otherwise data constraints wrong)
    const wantUnique = !!opts.unique
    const hasUnique = !!sameKey.unique
    if (wantUnique !== hasUnique) {
      console.warn('[indexes] unique mismatch; recreating', c.collectionName, sameKey.name)
      await dropIndexIfExists(c, sameKey.name)
    } else {
      return
    }
  }

  // If an index with the desired name exists but key differs, drop it.
  if (opts.name) {
    const named = existing.find(ix => ix.name === opts.name)
    if (named && !keyEq(named.key, key)) {
      console.warn('[indexes] name exists with different key; recreating', c.collectionName, opts.name)
      await dropIndexIfExists(c, opts.name)
    }
  }

  // Create (safe now)
  await c.createIndex(key, opts)
}

export async function ensureIndexes() {
  // users
  await ensureIndex(await col('users'), { email: 1 }, { unique: true, name: 'uniq_users_email' })

  // integrations
  const integrations = await col('integrations')
  await ensureIndex(integrations, { user_id: 1, provider: 1 }, { unique: true, name: 'uniq_integrations_user_provider' })
  await ensureIndex(integrations, { id: 1 }, { unique: true, name: 'uniq_integrations_id' })

  // locations
  const locations = await col('locations')

  // IMPORTANT: locations must be unique PER USER.
  // Otherwise two ParaMetrics users cannot import the same GBP location.
  const desiredLocKey = { user_id: 1, provider: 1, provider_location_name: 1 }

  // If you previously created a global unique index (no user_id), drop it to avoid multi-user conflicts.
  // (This is safe in dev; in prod you’d migrate carefully.)
  const legacyGlobalKey = { provider: 1, provider_account_name: 1, provider_location_name: 1 }
  const locIdx = await listIdx(locations)
  const legacyGlobal = locIdx.find(ix => keyEq(ix.key, legacyGlobalKey))
  if (legacyGlobal) {
    console.warn('[indexes] dropping legacy global unique index on locations:', legacyGlobal.name)
    await dropIndexIfExists(locations, legacyGlobal.name)
  }

  // Also handle your current crash case: an index exists with same key but different name.
  // ensureIndex() will detect and skip without throwing.
  await ensureIndex(locations, desiredLocKey, { unique: true, name: 'uniq_location_per_user_provider_location' })
  await ensureIndex(locations, { user_id: 1, updated_at: -1 }, { name: 'idx_locations_user_updated_at' })

  // posts
  const posts = await col('posts')
  await ensureIndex(posts, { created_at: -1 }, { name: 'idx_posts_created_at_desc' })
  await ensureIndex(posts, { status: 1, scheduled_at: 1 }, { name: 'idx_posts_status_scheduled' })

  // reviews
  const reviews = await col('reviews')
  await ensureIndex(reviews, { location_id: 1, provider_review_name: 1 }, { unique: true, name: 'uniq_reviews_location_provider_review' })
  await ensureIndex(reviews, { location_id: 1, updated_at: -1 }, { name: 'idx_reviews_location_updated_at' })
}
