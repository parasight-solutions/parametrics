import "dotenv/config"
import cron from 'node-cron'
import { col } from '../lib/mongo.js'
import { makeQueue } from '../lib/queues.js'
const q = makeQueue('post-publish')
console.log('Scheduler booted')

cron.schedule('* * * * *', async ()=>{
  const posts = await col('posts')
  const due = await posts.find({ status:'scheduled', scheduled_at: { $lte: new Date() } }).limit(50).toArray()
  for (const p of due) {
    await posts.updateOne({ id: p.id }, { $set:{ status:'queued', updated_at: new Date() }})
    await q.add('scheduled-publish', { postId: p.id }, { attempts:5, backoff:{ type:'exponential', delay:2000 }})
  }
})
