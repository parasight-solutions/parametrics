// apps/api/src/routes/posts.js
import { Router } from 'express'
import crypto from 'crypto'
import { col } from '../lib/mongo.js'
import { authenticate } from '../middleware/auth.js'
import { getActiveGoogleIntegration, ensureAccessToken } from '../integrations/google.store.js'
import { createLocalPost, listAccounts } from '../integrations/google.js'
import { makeQueue } from '../lib/queues.js'

const router = Router()
const publishQueue = makeQueue('post-publish')

function normalizeCreateBody(body = {}) {
  const locationId = body.locationId || body.location_id || body.location || ''
  const summary = body.summary || body.text || ''
  const imageUrl = body.imageUrl || body.image_url || null
  const callToActionUrl = body.callToActionUrl || body.call_to_action_url || null

  const scheduleAt = body.scheduleAt || body.scheduled_at || null
  const publishNow =
    typeof body.publishNow === 'boolean'
      ? body.publishNow
      : !scheduleAt // default: publish now if not scheduled

  return {
    locationId: String(locationId || ''),
    summary: String(summary || '').trim(),
    imageUrl: imageUrl ? String(imageUrl) : null,
    callToActionUrl: callToActionUrl ? String(callToActionUrl) : null,
    publishNow,
    scheduleAt: scheduleAt ? new Date(scheduleAt) : null,
  }
}

function safeErrString(e) {
  if (!e) return 'publish_failed'
  if (typeof e === 'string') return e
  const out = {
    message: e.message || 'google_error',
    status: e.status || undefined,
    body: e.body || undefined,
  }
  try { return JSON.stringify(out) } catch { return out.message }
}

async function assertLocationAccessible(accessToken, loc) {
  // If this token can’t see the account, posting will 404.
  const acc = String(loc?.provider_account_name || '').trim();
  if (!acc) throw new Error('location_missing_account_name');

  const data = await listAccounts(accessToken);
  const ok = (data?.accounts || []).some(a => a?.name === acc);

  if (!ok) {
    const e = new Error('account_mismatch');
    e.code = 'account_mismatch';
    e.data = { requiredAccount: acc };
    throw e;
  }
}

async function mapLocationsById(userId, locationIds) {
  const ids = Array.from(new Set((locationIds || []).filter(Boolean)))
  if (!ids.length) return new Map()

  const locations = await col('locations')
  const rows = await locations
    .find(
      { user_id: userId, id: { $in: ids } },
      { projection: { _id: 0, id: 1, title: 1, name: 1, provider_location_name: 1, provider_account_name: 1 } }
    )
    .toArray()

  const m = new Map()
  for (const r of rows) {
    m.set(r.id, {
      id: r.id,
      title: r.title || r.name || r.provider_location_name || r.id,
      provider_account_name: r.provider_account_name || null,
      provider_location_name: r.provider_location_name || null,
    })
  }
  return m
}

/**
 * Worker entrypoint: publish a post immediately.
 * Exported because workers import it.
 */
export async function publishPostNow(postId) {
  const posts = await col('posts')
  const locations = await col('locations')

  const post = await posts.findOne({ id: postId })
  if (!post) throw new Error('post_not_found')
  if (post.status === 'published') return { name: post.provider_post_name || null }

  const loc = await locations.findOne({ id: post.location_id, user_id: post.user_id, provider: 'google' })
  if (!loc) throw new Error('location_not_found')

  const integ = await getActiveGoogleIntegration(post.user_id)
  if (!integ) throw new Error('no_integration')

  const { access_token } = await ensureAccessToken(integ)

  // mark publishing
  await posts.updateOne(
    { id: postId, user_id: post.user_id },
    { $set: { status: 'publishing', updated_at: new Date() } }
  )

  try {
    const payload = {
      summary: post.summary,
      languageCode: 'en-US',
      // TODO: add media + CTA later
    }

    const created = await createLocalPost(
      access_token,
      loc.provider_account_name,
      loc.provider_location_name,
      payload
    )

    await posts.updateOne(
      { id: postId, user_id: post.user_id },
      {
        $set: {
          status: 'published',
          provider_post_name: created?.name || null,
          provider_error: null,
          updated_at: new Date(),
        },
      }
    )

    return created
  } catch (e) {
    await posts.updateOne(
      { id: postId, user_id: post.user_id },
      {
        $set: {
          status: 'failed',
          provider_error: safeErrString(e),
          updated_at: new Date(),
        },
      }
    )
    throw e
  }
}

// GET /api/v1/posts?locationId=...  (optional)
router.get('/', authenticate, async (req, res) => {
  const userId = req.user.user_id
  const locationId = (req.query.locationId || req.query.location_id || '').toString().trim()

  const q = { user_id: userId }
  if (locationId) q.location_id = locationId

  const postsCol = await col('posts')
  const rows = await postsCol.find(q).sort({ created_at: -1 }).toArray()

  const locMap = await mapLocationsById(userId, rows.map(r => r.location_id))

  const posts = rows.map(p => {
    const loc = locMap.get(p.location_id) || null
    return {
      id: p.id,
      user_id: p.user_id,
      location_id: p.location_id,

      location: loc ? { id: loc.id, title: loc.title } : { id: p.location_id, title: p.location_id },

      summary: p.summary,
      image_url: p.image_url || null,
      call_to_action_url: p.call_to_action_url || null,

      status: p.status,
      scheduled_at: p.scheduled_at || null,

      provider_post_name: p.provider_post_name || null,
      provider_error: p.provider_error || null,

      created_at: p.created_at,
      updated_at: p.updated_at,
    }
  })

  res.json({ posts })
})

router.post('/', authenticate, async (req, res) => {
  const userId = req.user.user_id
  const b = normalizeCreateBody(req.body)

  if (!b.locationId) return res.status(400).json({ error: { code: 'bad_request', message: 'locationId required' } })
  if (!b.summary) return res.status(400).json({ error: { code: 'bad_request', message: 'summary required' } })

  const locations = await col('locations')
  const loc = await locations.findOne({ id: b.locationId, user_id: userId, provider: 'google' })
  if (!loc) return res.status(404).json({ error: { code: 'not_found', message: 'location not found' } })
  try {
    const integ = await getActiveGoogleIntegration(userId);
    if (!integ) return res.status(409).json({ error: { code: 'no_integration', message: 'Google not connected' } });

    const tokenObj = await ensureAccessToken(integ);
    const accessToken = tokenObj?.access_token || tokenObj?.accessToken || tokenObj;

    await assertLocationAccessible(accessToken, loc);
  } catch (e) {
    if (e?.code === 'account_mismatch') {
      return res.status(409).json({
        error: {
          code: 'account_mismatch',
          message: 'This location belongs to a different Google account. Reconnect with the correct Google account and re-import locations.',
          data: e.data || null,
        }
      });
    }
    return res.status(500).json({ error: { code: 'server_error', message: e?.message || 'server_error' } });
  }

  const id = crypto.randomUUID()
  const now = new Date()

  const doc = {
    id,
    user_id: userId,
    location_id: loc.id,

    summary: b.summary,
    image_url: b.imageUrl,
    call_to_action_url: b.callToActionUrl,

    status: b.publishNow ? 'queued' : 'scheduled',
    scheduled_at: b.publishNow ? null : b.scheduleAt,

    provider_post_name: null,
    provider_error: null,

    created_at: now,
    updated_at: now,
  }

  await (await col('posts')).insertOne(doc)

  if (b.publishNow) {
    await publishQueue.add(
      'manual-publish',
      { postId: id, userId },
      { attempts: 5, backoff: { type: 'exponential', delay: 2000 } }
    )
  }

  return res.json({
    post: {
      ...doc,
      location: { id: loc.id, title: loc.title || loc.name || loc.provider_location_name || loc.id },
    }
  })
})

// Edit post (summary + schedule/publish)
router.patch('/:id', authenticate, async (req, res) => {
  const userId = req.user.user_id
  const id = String(req.params.id || '')
  const posts = await col('posts')

  const post = await posts.findOne({ id, user_id: userId })
  if (!post) return res.status(404).json({ error: { code: 'not_found', message: 'post not found' } })

  if (post.status === 'published') {
    return res.status(409).json({ error: { code: 'conflict', message: 'published posts cannot be edited' } })
  }

  const body = req.body || {}
  const summary = (body.summary ?? body.text)
  const publishNow = typeof body.publishNow === 'boolean' ? body.publishNow : undefined
  const scheduleAtRaw = (body.scheduleAt ?? body.scheduled_at)

  const $set = { updated_at: new Date() }

  if (typeof summary === 'string') $set.summary = summary.trim()

  // schedule logic:
  // - publishNow=true => queued now
  // - scheduleAt provided => scheduled
  // - scheduleAt explicitly empty/null and publishNow not true => queued now
  let enqueue = false

  if (publishNow === true) {
    $set.status = 'queued'
    $set.scheduled_at = null
    $set.provider_error = null
    enqueue = true
  } else if (scheduleAtRaw !== undefined) {
    if (scheduleAtRaw) {
      const dt = new Date(scheduleAtRaw)
      if (Number.isNaN(dt.getTime())) {
        return res.status(400).json({ error: { code: 'bad_request', message: 'invalid scheduleAt' } })
      }
      $set.status = 'scheduled'
      $set.scheduled_at = dt
    } else {
      $set.status = 'queued'
      $set.scheduled_at = null
      $set.provider_error = null
      enqueue = true
    }
  }

  await posts.updateOne({ id, user_id: userId }, { $set })

  if (enqueue) {
    await publishQueue.add(
      'edit-publish',
      { postId: id, userId },
      { attempts: 5, backoff: { type: 'exponential', delay: 2000 } }
    )
  }

  const updated = await posts.findOne({ id, user_id: userId }, { projection: { _id: 0 } })
  return res.json({ post: updated })
})

// Retry failed post
router.post('/:id/retry', authenticate, async (req, res) => {
  const userId = req.user.user_id
  const id = String(req.params.id || '')
  const posts = await col('posts')

  const post = await posts.findOne({ id, user_id: userId })
  if (!post) return res.status(404).json({ error: { code: 'not_found', message: 'post not found' } })

  if (post.status !== 'failed') {
    return res.status(409).json({ error: { code: 'conflict', message: 'only failed posts can be retried' } })
  }

  await posts.updateOne(
    { id, user_id: userId },
    { $set: { status: 'queued', provider_error: null, updated_at: new Date() } }
  )

  await publishQueue.add(
    'manual-retry',
    { postId: id, userId },
    { attempts: 5, backoff: { type: 'exponential', delay: 2000 } }
  )

  return res.json({ ok: true })
})

router.delete('/:id', authenticate, async (req, res) => {
  const userId = req.user.user_id
  const id = String(req.params.id || '')
  await (await col('posts')).deleteOne({ id, user_id: userId })
  res.json({ ok: true })
})

export default router
