// apps/api/src/routes/integrations.google.js
import { Router } from 'express'
import crypto from 'crypto'
import { signJwt, verifyJwt } from '../lib/jwt.js'
import { col } from '../lib/mongo.js'
import { encJson, decJson } from '../lib/crypto.js'
import {
  getActiveGoogleIntegration,
  upsertGoogleIntegration,
  ensureAccessToken
} from '../integrations/google.store.js'
import {
  listAccounts,
  listLocations,
  fetchPerformance,
  listLocationMedia
} from '../integrations/google.js'
import { authenticate } from '../middleware/auth.js'

const router = Router()
const IS_PROD = (process.env.NODE_ENV || 'development') === 'production'

// --- Google OAuth constants ---
const AUTH_BASE = 'https://accounts.google.com/o/oauth2/v2/auth'
const TOKEN_URL = 'https://oauth2.googleapis.com/token'
const TOKENINFO_URL = 'https://oauth2.googleapis.com/tokeninfo'
const SCOPES = [
  'https://www.googleapis.com/auth/business.manage',
  'openid', 'email', 'profile'
].join(' ')

const redirectUri = () =>
  process.env.GOOGLE_REDIRECT_URI ||
  `http://localhost:${process.env.PORT || 5050}/api/v1/integrations/google/callback`

const postConnectRedirect = () =>
  process.env.GOOGLE_POST_CONNECT_REDIRECT ||
  'http://localhost:5173/integrations/google/connected'

function normalizeAccount(a) {
  const accountId = (a?.name || "").split("/").pop() || null
  return {
    name: a?.name || null,                // accounts/123
    accountId,
    accountName: a?.accountName || null,  // display name
    type: a?.type || null,
    role: a?.role || null,
    state: a?.state || null,
    verified: a?.verificationState || null,
  }
}

function formatAddress(addr) {
  if (!addr) return null
  const parts = [
    ...(addr.addressLines || []),
    addr.locality,
    addr.administrativeArea,
    addr.postalCode,
    addr.regionCode,
  ].filter(Boolean)
  return parts.join(", ")
}

function normalizeLocation(loc) {
  const locationId = (loc?.name || "").split("/").pop() || null // locations/XXXX
  const primaryPhone =
    loc?.phoneNumbers?.primaryPhone ||
    loc?.phoneNumbers?.additionalPhones?.[0] ||
    null

  return {
    name: loc?.name || null, // locations/xxxx
    locationId,
    title: loc?.title || null,
    storeCode: loc?.storeCode || null,
    websiteUri: loc?.websiteUri || null,
    primaryPhone,
    address: formatAddress(loc?.storefrontAddress),
    mapsUri: loc?.metadata?.mapsUri || null,
    placeId: loc?.metadata?.placeId || null,
    openInfo: loc?.openInfo || null,
  }
}

// ---------- JWT helpers ----------
function unsafeParseJwt(t) {
  try {
    const parts = String(t).split('.')
    if (parts.length < 2) return null
    const p = parts[1].replace(/-/g, '+').replace(/_/g, '/')
    const pad = '='.repeat((4 - (p.length % 4)) % 4)
    return JSON.parse(Buffer.from(p + pad, 'base64').toString('utf8'))
  } catch { return null }
}

// Accept JWT from Authorization: Bearer ... OR ?t=...
function userFromReq(req) {
  const header = req.headers.authorization || ''
  const m = header.match(/^Bearer\s+(.+)$/i)
  const q = (req.query?.t || '').toString()

  if (m) {
    try {
      const tok = verifyJwt(m[1])
      return { user_id: tok.user_id, role: tok.role }
    } catch (e) {
      if (!IS_PROD) {
        const dec = unsafeParseJwt(m[1])
        if (dec?.user_id) {
          console.warn('[integrations.google/start] DEV accept unsigned header jwt for user_id=', dec.user_id)
          return { user_id: dec.user_id, role: dec.role || 'user' }
        }
      }
      console.warn('[integrations.google/start] header token verify failed:', e?.message || e)
    }
  }

  if (q) {
    try {
      const tok = verifyJwt(q)
      return { user_id: tok.user_id, role: tok.role }
    } catch (e) {
      if (!IS_PROD) {
        const dec = unsafeParseJwt(q)
        if (dec?.user_id) {
          console.warn('[integrations.google/start] DEV accept unsigned query jwt for user_id=', dec.user_id)
          return { user_id: dec.user_id, role: dec.role || 'user' }
        }
      }
      console.warn('[integrations.google/start] query token verify failed:', e?.message || e)
    }
  }

  return null
}

// ----------------------
// 1) START (no auth mw)
// ----------------------
router.get('/start', (req, res) => {
  const clientId = process.env.GOOGLE_CLIENT_ID || ''
  if (!clientId) {
    return res.status(500).json({ error: { code: 'config', message: 'GOOGLE_CLIENT_ID missing in .env' } })
  }

  const u = userFromReq(req)
  if (!u?.user_id) {
    console.error('[integrations.google/start] unauthorized: missing/invalid jwt. header=', !!req.headers.authorization, 'tParam=', !!req.query?.t)
    return res.status(401).json({ error: { code: 'unauthorized', message: 'pass JWT as Bearer or ?t=' } })
  }

  const state = signJwt({ uid: u.user_id, at: Date.now() }, { expiresIn: '10m' })
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri(),
    response_type: 'code',
    scope: SCOPES,
    access_type: 'offline',
    prompt: 'consent',
    include_granted_scopes: 'true',
    state
  })
  res.redirect(`${AUTH_BASE}?${params.toString()}`)
})

// -------------------------
// 2) CALLBACK (no auth mw)
// -------------------------
router.get('/callback', async (req, res) => {
  const { code, state } = req.query
  if (!code || !state) return res.status(400).send('Missing code/state')

  let uid
  try { uid = verifyJwt(String(state)).uid } catch { return res.status(400).send('Bad state') }

  const body = new URLSearchParams({
    code: String(code),
    client_id: process.env.GOOGLE_CLIENT_ID || '',
    client_secret: process.env.GOOGLE_CLIENT_SECRET || '',
    redirect_uri: redirectUri(),
    grant_type: 'authorization_code'
  })

  const tokRes = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  })

  if (!tokRes.ok) {
    const msg = await tokRes.text().catch(() => '')
    console.error('[integrations.google/callback] token exchange failed:', tokRes.status, msg)
    return res.status(502).send('Token exchange failed')
  }

  const tok = await tokRes.json()
  if (!tok.id_token) return res.status(502).send('No id_token')

  const inf = await fetch(`${TOKENINFO_URL}?id_token=${encodeURIComponent(tok.id_token)}`)
  if (!inf.ok) return res.status(502).send('Invalid id_token')
  const info = await inf.json()

  // IMPORTANT: preserve prior refresh_token if Google doesn't return it on reconnect
  let prev = {}
  try {
    const existing = await getActiveGoogleIntegration(uid)
    if (existing?.secrets_json) prev = decJson(existing.secrets_json || '{}') || {}
  } catch { }

  const secrets = {
    access_token: tok.access_token,
    refresh_token: tok.refresh_token || prev.refresh_token || null,
    expiry_date: Math.floor(Date.now() / 1000) + Number(tok.expires_in || 3600),
    scope: tok.scope,
    token_type: tok.token_type || 'Bearer',
    id_token: tok.id_token,
    email: info.email || prev.email || null,
    sub: info.sub || prev.sub || null
  }

  await upsertGoogleIntegration(uid, {
    provider: 'google',
    scopes: (tok.scope || '').split(' ').filter(Boolean),
    secrets_json: encJson({ ...prev, ...secrets })
  })

  res.redirect(postConnectRedirect())
})

// ---------------------------
// 3) STATUS (Bearer auth)
// ---------------------------
router.get('/status', authenticate, async (req, res) => {
  try {
    const integ = await getActiveGoogleIntegration(req.user.user_id)
    if (!integ) return res.json({ connected: false })

    let email = null
    try {
      const secrets = decJson(integ.secrets_json || '{}')
      email = secrets.email || null
    } catch { }

    return res.json({
      connected: true,
      email,
      scopes: integ.scopes || [],
      updated_at: integ.updated_at || null,
    })
  } catch {
    return res.status(502).json({ error: { code: 'status_failed' } })
  }
})

// ---------------------------
// 4) ACCOUNTS (Bearer auth)
// ---------------------------
const ACCOUNTS_CACHE = new Map() // user_id -> { ts, data, inflight, cooldownUntil }
const ACCOUNTS_TTL_MS = 60_000
const COOLDOWN_MS = 60_000

router.get('/accounts', authenticate, async (req, res) => {
  const uid = req.user.user_id
  const entry = ACCOUNTS_CACHE.get(uid) || {}
  const now = Date.now()

  if (entry.cooldownUntil && now < entry.cooldownUntil) {
    if (entry.data) return res.json({ accounts: (entry.data.accounts || []).map(normalizeAccount) });
    return res.status(502).json({ error: { code: 'accounts_list_failed' } });
  }

  const fresh = entry.ts && (now - entry.ts < ACCOUNTS_TTL_MS);
  if (fresh && entry.data) return res.json({ accounts: (entry.data.accounts || []).map(normalizeAccount) });

  if (entry.inflight) {
    try {
      const data = await entry.inflight
      return res.json({ accounts: (data.accounts || []).map(normalizeAccount) })
    } catch {
      return res.status(502).json({ error: { code: 'accounts_list_failed' } })
    }
  }

  const p = (async () => {
    try {
      const integ = await getActiveGoogleIntegration(uid)
      if (!integ) throw Object.assign(new Error('no_integration'), { code: 'no_integration' })

      const { access_token } = await ensureAccessToken(uid)
      const data = await listAccounts(access_token)
      ACCOUNTS_CACHE.set(uid, { ts: Date.now(), data, inflight: null })
      return data
    } catch (err) {
      if (err?.status === 429) {
        ACCOUNTS_CACHE.set(uid, { ...entry, inflight: null, cooldownUntil: Date.now() + COOLDOWN_MS })
      } else {
        ACCOUNTS_CACHE.set(uid, { ...entry, inflight: null })
      }
      throw err
    }
  })()

  ACCOUNTS_CACHE.set(uid, { ts: 0, data: null, inflight: p })

  try {
    const data = await p
    return res.json({ accounts: (data.accounts || []).map(normalizeAccount) })
  } catch (err) {
    console.error('[integrations.google/accounts] failed', err?.status || '', err?.body || err?.message || err)
    return res.status(502).json({ error: { code: 'accounts_list_failed' } })
  }
})

// ---------------------------
// 5) LOCATIONS (Bearer auth)
// ---------------------------
router.get('/locations', authenticate, async (req, res) => {
  try {
    const accountName = String(req.query.accountName || '')
    if (!accountName) return res.status(400).json({ error: { code: 'bad_request', message: 'accountName required' } })

    const integ = await getActiveGoogleIntegration(req.user.user_id)
    if (!integ) return res.status(404).json({ error: { code: 'no_integration' } })

    const { access_token } = await ensureAccessToken(req.user.user_id)
    const data = await listLocations(access_token, accountName)

    return res.json({ locations: (data.locations || []).map(normalizeLocation) })
  } catch (err) {
    console.error('[integrations.google/locations] failed', err?.status || '', err?.body || err?.message || err)
    return res.status(502).json({ error: { code: 'locations_list_failed' } })
  }
})

// ---------------------------
// 6) LOCATIONS IMPORT (Bearer auth)
// ---------------------------
router.post('/locations/import', authenticate, async (req, res) => {
  try {
    const { accountName } = req.body || {}
    if (!accountName) return res.status(400).json({ error: { code: 'bad_request', message: 'accountName required' } })

    const integ = await getActiveGoogleIntegration(req.user.user_id)
    if (!integ) return res.status(404).json({ error: { code: 'no_integration' } })

    const { access_token } = await ensureAccessToken(req.user.user_id)
    const data = await listLocations(access_token, accountName)

    const list = data.locations || []
    const locations = await col('locations')
    let upserted = 0

    for (const loc of list) {
      const norm = normalizeLocation(loc)

      const doc = {
        user_id: req.user.user_id,
        provider: 'google',
        provider_account_name: accountName,     // accounts/xxx
        provider_location_name: norm.name,      // locations/yyy
        status: 'active',

        title: norm.title,
        storeCode: norm.storeCode,
        websiteUri: norm.websiteUri,
        primaryPhone: norm.primaryPhone,
        address: norm.address,
        mapsUri: norm.mapsUri,
        placeId: norm.placeId,

        updated_at: new Date(),
      }

      await locations.updateOne(
        { user_id: req.user.user_id, provider: 'google', provider_location_name: doc.provider_location_name },
        { $set: doc, $setOnInsert: { id: crypto.randomUUID(), created_at: new Date() } },
        { upsert: true }
      )

      upserted++
    }

    return res.json({ inserted: upserted })
  } catch (err) {
    console.error('[integrations.google/locations.import] failed', err?.status || '', err?.body || err?.message || err)
    return res.status(502).json({ error: { code: 'locations_import_failed' } })
  }
})

// ---------------------------
// 7) LOCATION MEDIA (logo/profile photo)
// ---------------------------
router.get('/location-media', authenticate, async (req, res) => {
  try {
    const accountName = String(req.query.accountName || '')
    const locationName = String(req.query.locationName || '')
    if (!accountName || !locationName) {
      return res.status(400).json({ error: { code: 'bad_request', message: 'accountName and locationName required' } })
    }

    const integ = await getActiveGoogleIntegration(req.user.user_id)
    if (!integ) return res.status(404).json({ error: { code: 'no_integration' } })

    const { access_token } = await ensureAccessToken(integ)
    const data = await listLocationMedia(accountName, locationName, access_token, { pageSize: 10 })

    // pick best URLs for UI
    const items = data.mediaItems || []
    const pick = (cat) => items.find(x => (x?.mediaFormat?.category || x?.category) === cat) || null

    const profile = pick('PROFILE') || pick('LOGO') || null
    const cover = pick('COVER') || null

    return res.json({
      profilePhotoUrl: profile?.googleUrl || profile?.mediaFormat?.googleUrl || null,
      coverPhotoUrl: cover?.googleUrl || cover?.mediaFormat?.googleUrl || null,
      count: items.length
    })
  } catch (err) {
    console.error('[integrations.google/location-media] failed', err?.status || '', err?.body || err?.message || err)
    return res.status(502).json({ error: { code: 'location_media_failed' } })
  }
})

// ---------------------------
// 8) PERFORMANCE (Dashboard)
// ---------------------------

// GBP Performance API valid DailyMetric values (see docs)
// https://developers.google.com/my-business/reference/performance/rest/v1/locations/fetchMultiDailyMetricsTimeSeries#dailymetric
const ALLOWED_DAILY_METRICS = new Set([
  'WEBSITE_CLICKS',
  'CALL_CLICKS',
  'BUSINESS_DIRECTION_REQUESTS',
  'BUSINESS_IMPRESSIONS_DESKTOP_SEARCH',
  'BUSINESS_IMPRESSIONS_MOBILE_SEARCH',
  'BUSINESS_IMPRESSIONS_DESKTOP_MAPS',
  'BUSINESS_IMPRESSIONS_MOBILE_MAPS',
  'BUSINESS_CONVERSATIONS',
  'BUSINESS_BOOKINGS',
  'BUSINESS_FOOD_ORDERS',
  'BUSINESS_FOOD_MENU_CLICKS',
])

// Back-compat: map your old “aggregate” names to the actual API enums
const METRIC_ALIASES = {
  // legacy -> valid
  DIRECTIONS_REQUESTS: ['BUSINESS_DIRECTION_REQUESTS'],
  BUSINESS_IMPRESSIONS_SEARCH: [
    'BUSINESS_IMPRESSIONS_DESKTOP_SEARCH',
    'BUSINESS_IMPRESSIONS_MOBILE_SEARCH',
  ],
  BUSINESS_IMPRESSIONS_MAPS: [
    'BUSINESS_IMPRESSIONS_DESKTOP_MAPS',
    'BUSINESS_IMPRESSIONS_MOBILE_MAPS',
  ],
}

function normalizeMetricName(m) {
  return String(m || '').trim().toUpperCase()
}

function expandAndValidateMetrics(requestedMetrics) {
  const requested = (requestedMetrics || [])
    .map(normalizeMetricName)
    .filter(Boolean)

  const groups = [] // [{ key, expanded: [] }]
  const expandedSet = new Set()

  for (const key of requested) {
    const expanded = METRIC_ALIASES[key] || [key]

    for (const m of expanded) {
      if (!ALLOWED_DAILY_METRICS.has(m)) {
        const e = new Error(`invalid_metric:${m}`)
        e.code = 'invalid_metric'
        e.metric = m
        e.allowed = Array.from(ALLOWED_DAILY_METRICS).sort()
        throw e
      }
      expandedSet.add(m)
    }

    groups.push({ key, expanded })
  }

  return { requested, expanded: Array.from(expandedSet), groups }
}

function buildTotalsByMetric(raw) {
  // raw.multiDailyMetricTimeSeries[*].dailyMetricTimeSeries[*]
  const totals = new Map()

  for (const series of (raw?.multiDailyMetricTimeSeries || [])) {
    for (const s of (series?.dailyMetricTimeSeries || [])) {
      const metric = s?.dailyMetric
      if (!metric) continue
      const values = s?.timeSeries?.datedValues || []
      let sum = 0
      for (const v of values) sum += Number(v?.value || 0)
      totals.set(metric, (totals.get(metric) || 0) + sum)
    }
  }

  return totals
}

router.get('/performance', authenticate, async (req, res) => {
  try {
    const locationId = String(req.query.locationId || '')
    const days = Math.max(1, Math.min(90, Number(req.query.days || 30)))

    if (!locationId) {
      return res.status(400).json({ error: { code: 'bad_request', message: 'locationId required' } })
    }

    const locations = await col('locations')
    const loc = await locations.findOne({ id: locationId, user_id: req.user.user_id, provider: 'google' })
    if (!loc) {
      return res.status(404).json({ error: { code: 'not_found', message: 'location not found' } })
    }

    const integ = await getActiveGoogleIntegration(req.user.user_id)
    if (!integ) {
      return res.status(404).json({ error: { code: 'no_integration' } })
    }

    const { access_token } = await ensureAccessToken(integ)

    // If caller passes metrics=... use it. Otherwise keep your legacy list (we’ll alias-expand it).
    const requestedMetrics = req.query.metrics
      ? String(req.query.metrics).split(',').map(s => s.trim()).filter(Boolean)
      : [
        'WEBSITE_CLICKS',
        'CALL_CLICKS',
        'DIRECTIONS_REQUESTS',
        'BUSINESS_IMPRESSIONS_SEARCH',
        'BUSINESS_IMPRESSIONS_MAPS',
      ]

    const { requested, expanded, groups } = expandAndValidateMetrics(requestedMetrics)

    // Call API using ONLY valid enums
    const raw = await fetchPerformance(access_token, loc.provider_location_name, { days, metrics: expanded })

    const totalsByMetric = buildTotalsByMetric(raw)

    // Return totals in the *requested* keys (including legacy names), aggregating where needed
    const out = groups.map(g => {
      let total = 0
      for (const m of g.expanded) total += Number(totalsByMetric.get(m) || 0)
      return { metric: g.key, total }
    })

    return res.json({
      range: { days },
      metrics: out,
      // optional debug field (remove if you don’t want)
      expanded_metrics_used: expanded,
    })
  } catch (err) {
    if (err?.code === 'invalid_metric') {
      return res.status(400).json({
        error: {
          code: 'bad_request',
          message: `Invalid metric: ${err.metric}`,
          allowed: err.allowed,
        },
      })
    }

    const status = err?.status || 502
    const body = err?.body || null

    console.error(
      '[integrations.google/performance] failed',
      'status=', status,
      'body=', body || err?.message || err
    )

    return res.status(502).json({
      error: {
        code: 'performance_failed',
        message: err?.message || 'performance_failed',
        status,
        body,
      }
    })
  }
})

export default router
