// apps/api/src/routes/locations.js
import { Router } from 'express'
import { col } from '../lib/mongo.js'
import { authenticate } from '../middleware/auth.js'

const router = Router()

router.get('/', authenticate, async (req, res) => {
  const c = await col('locations')
  const rows = await c
    .find({ user_id: req.user.user_id })
    .sort({ updated_at: -1 })
    .toArray()

  const locations = rows.map(l => ({
    id: l.id,
    provider: l.provider,
    title: l.title || l.name || l.provider_location_name,
    address: l.address || null,
    primaryPhone: l.primaryPhone || null,
    mapsUri: l.mapsUri || null,
    websiteUri: l.websiteUri || null,
    provider_account_name: l.provider_account_name,
    provider_location_name: l.provider_location_name,
    updated_at: l.updated_at,
  }))

  return res.json({ locations })
})

router.delete('/:id', authenticate, async (req, res) => {
  const c = await col('locations')
  const id = String(req.params.id || '')
  await c.deleteOne({ id, user_id: req.user.user_id })
  return res.json({ ok: true })
})

export default router
