// apps/api/src/routes/integrations.google.extras.js
import express from 'express';
import { authenticate } from '../middleware/auth.js';
import { col } from '../lib/mongo.js';
import { getActiveGoogleIntegration, ensureAccessToken } from '../integrations/google.store.js';
import {
    fetchMultiDailyMetricsTimeSeries,
    listReviews,
    updateReviewReply,
    listLocationMedia,
} from '../integrations/google.js';

const router = express.Router();

function sendGoogleFailure(res, e, fallbackCode = 'google_error') {
    const status = e?.status || 502;
    const body = e?.body || null;

    return res.status(502).json({
        error: {
            code: fallbackCode,
            message: e?.message || fallbackCode,
            status,
            body,
        },
    });
}

function toDateParts(d) {
    return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() };
}

function ymd(d) {
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

async function getOwnedLocation(userId, locationId) {
    const locations = await col('locations');
    const doc = await locations.findOne({ id: locationId, user_id: userId });
    if (!doc) return null;
    if (!doc.provider_account_name || !doc.provider_location_name) return null;
    return doc;
}

async function getAccessTokenForUser(userId) {
  const integ = await getActiveGoogleIntegration(userId);
  if (!integ) {
    const e = new Error('no_integration');
    e.code = 'no_integration';
    throw e;
  }
  const tokenObj = await ensureAccessToken(integ); // ✅ single contract
  const accessToken = tokenObj?.access_token || tokenObj?.accessToken || tokenObj; // tolerate your old shapes
  if (!accessToken || typeof accessToken !== 'string') {
    const e = new Error('missing_access_token');
    e.code = 'missing_access_token';
    throw e;
  }
  return accessToken;
}

// GET /api/v1/integrations/google/performance?locationId=...&days=30&metrics=...

const ALLOWED_DAILY_METRICS = new Set([
    'WEBSITE_CLICKS',
    'CALL_CLICKS',
    'BUSINESS_DIRECTION_REQUESTS',
    'BUSINESS_IMPRESSIONS_DESKTOP_SEARCH',
    'BUSINESS_IMPRESSIONS_MOBILE_SEARCH',
    'BUSINESS_IMPRESSIONS_DESKTOP_MAPS',
    'BUSINESS_IMPRESSIONS_MOBILE_MAPS',
    'BUSINESS_CONVERSATIONS',
    'BUSINESS_BOOKINGS',
    'BUSINESS_FOOD_ORDERS',
    'BUSINESS_FOOD_MENU_CLICKS',
])

const METRIC_ALIASES = {
    DIRECTIONS_REQUESTS: ['BUSINESS_DIRECTION_REQUESTS'],
    BUSINESS_IMPRESSIONS_SEARCH: [
        'BUSINESS_IMPRESSIONS_DESKTOP_SEARCH',
        'BUSINESS_IMPRESSIONS_MOBILE_SEARCH',
    ],
    BUSINESS_IMPRESSIONS_MAPS: [
        'BUSINESS_IMPRESSIONS_DESKTOP_MAPS',
        'BUSINESS_IMPRESSIONS_MOBILE_MAPS',
    ],
}

function normalizeMetricName(m) {
    return String(m || '').trim().toUpperCase()
}

function expandAndValidateMetrics(requestedMetrics) {
    const requested = (requestedMetrics || [])
        .map(normalizeMetricName)
        .filter(Boolean)

    const groups = []
    const expandedSet = new Set()

    for (const key of requested) {
        const expanded = METRIC_ALIASES[key] || [key]
        for (const m of expanded) {
            if (!ALLOWED_DAILY_METRICS.has(m)) {
                const e = new Error(`invalid_metric:${m}`)
                e.code = 'invalid_metric'
                e.metric = m
                e.allowed = Array.from(ALLOWED_DAILY_METRICS).sort()
                throw e
            }
            expandedSet.add(m)
        }
        groups.push({ key, expanded })
    }

    return { requested, expanded: Array.from(expandedSet), groups }
}

function buildPointsByMetric(raw) {
    // metric -> Map(date -> value)
    const points = new Map()

    for (const series of (raw?.multiDailyMetricTimeSeries || [])) {
        for (const s of (series?.dailyMetricTimeSeries || [])) {
            const metric = s?.dailyMetric
            if (!metric) continue

            if (!points.has(metric)) points.set(metric, new Map())
            const bucket = points.get(metric)

            for (const v of (s?.timeSeries?.datedValues || [])) {
                const d = v?.date
                if (!d?.year || !d?.month || !d?.day) continue
                const key = `${d.year}-${String(d.month).padStart(2, '0')}-${String(d.day).padStart(2, '0')}`
                bucket.set(key, (bucket.get(key) || 0) + Number(v?.value || 0))
            }
        }
    }

    return points
}

router.get('/performance-series', authenticate, async (req, res) => {
    try {
        const userId = req.user.user_id
        const locationId = req.query.locationId || req.query.location_id
        const days = Math.min(Math.max(parseInt(req.query.days || '30', 10), 1), 366)

        if (!locationId) {
            return res.status(400).json({ error: { code: 'bad_request', message: 'locationId required' } })
        }

        const loc = await getOwnedLocation(userId, locationId)
        if (!loc) {
            return res.status(404).json({ error: { code: 'not_found', message: 'location not found' } })
        }

        const token = await ensureAccessToken(userId)

        const requestedMetrics = (req.query.metrics
            ? String(req.query.metrics).split(',')
            : [
                'WEBSITE_CLICKS',
                'CALL_CLICKS',
                'DIRECTIONS_REQUESTS',
                'BUSINESS_IMPRESSIONS_SEARCH',
                'BUSINESS_IMPRESSIONS_MAPS',
            ]
        ).map(s => s.trim()).filter(Boolean)

        const { expanded, groups } = expandAndValidateMetrics(requestedMetrics)

        const end = new Date()
        const start = new Date(end.getTime() - (days - 1) * 86400000)

        const raw = await fetchMultiDailyMetricsTimeSeries(
            loc.provider_location_name,
            token.access_token,
            { dailyMetrics: expanded, startDate: toDateParts(start), endDate: toDateParts(end) }
        )

        const pointsByMetric = buildPointsByMetric(raw)

        const series = groups.map(g => {
            // aggregate date-wise across expanded metrics
            const agg = new Map()
            for (const m of g.expanded) {
                const mp = pointsByMetric.get(m) || new Map()
                for (const [date, val] of mp.entries()) {
                    agg.set(date, (agg.get(date) || 0) + val)
                }
            }

            const points = Array.from(agg.entries())
                .sort((a, b) => a[0].localeCompare(b[0]))
                .map(([date, value]) => ({ date, value }))

            const total = points.reduce((s, p) => s + p.value, 0)
            return { metric: g.key, total, points }
        })

        return res.json({
            location: { id: loc.id, title: loc.title, provider: loc.provider },
            range: { start: ymd(start), end: ymd(end), days },
            metrics: series,
            expanded_metrics_used: expanded,
        })
    } catch (e) {
        if (e?.code === 'invalid_metric') {
            return res.status(400).json({
                error: { code: 'bad_request', message: `Invalid metric: ${e.metric}`, allowed: e.allowed },
            });
        }

        // If this is from integrations/google.js callGoogleJson(), it will have .status + .body
        if (e?.message === 'google_http_error') {
            return sendGoogleFailure(res, e, 'performance_failed');
        }

        return res.status(500).json({
            error: { code: 'server_error', message: e?.message || 'server_error', data: e?.data || null },
        });
    }
})

// GET /api/v1/integrations/google/reviews?locationId=...
router.get('/reviews', authenticate, async (req, res) => {
    try {
        const userId = req.user.user_id;
        const locationId = req.query.locationId || req.query.location_id;
        if (!locationId) return res.status(400).json({ error: { code: 'bad_request', message: 'locationId required' } });

        const loc = await getOwnedLocation(userId, locationId);
        if (!loc) return res.status(404).json({ error: { code: 'not_found', message: 'location not found' } });

        const accessToken = await getAccessTokenForUser(userId);

        const data = await listReviews(
            loc.provider_account_name,
            loc.provider_location_name,
            accessToken,
            { pageSize: 50, orderBy: 'updateTime desc' }
        );

        return res.json({ reviews: data.reviews || [], nextPageToken: data.nextPageToken || null });
    } catch (e) {
        return res.status(500).json({ error: { code: 'server_error', message: e.message, data: e.data || null } });
    }
});

// PUT /api/v1/integrations/google/reviews/reply  { reviewName, comment }
router.put('/reviews/reply', authenticate, async (req, res) => {
    try {
        const userId = req.user.user_id;
        const { reviewName, comment } = req.body || {};
        if (!reviewName || !comment) {
            return res.status(400).json({ error: { code: 'bad_request', message: 'reviewName + comment required' } });
        }
        const accessToken = await getAccessTokenForUser(userId);
        const out = await updateReviewReply(reviewName, comment, accessToken);
        return res.json({ reply: out });
    } catch (e) {
        return res.status(500).json({ error: { code: 'server_error', message: e.message, data: e.data || null } });
    }
});

// GET /api/v1/integrations/google/media?locationId=...
router.get('/media', authenticate, async (req, res) => {
    try {
        const userId = req.user.user_id;
        const locationId = req.query.locationId || req.query.location_id;
        if (!locationId) return res.status(400).json({ error: { code: 'bad_request', message: 'locationId required' } });

        const loc = await getOwnedLocation(userId, locationId);
        if (!loc) return res.status(404).json({ error: { code: 'not_found', message: 'location not found' } });

        const accessToken = await getAccessTokenForUser(userId);
        const data = await listLocationMedia(loc.provider_account_name, loc.provider_location_name, accessToken, { pageSize: 10 });

        return res.json({ mediaItems: data.mediaItems || [] });
    } catch (e) {
        return res.status(500).json({ error: { code: 'server_error', message: e.message, data: e.data || null } });
    }
});

export default router;
