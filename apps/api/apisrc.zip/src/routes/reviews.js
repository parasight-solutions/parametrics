// apps/api/src/routes/reviews.js
import { Router } from 'express'
import { col } from '../lib/mongo.js'
import { authenticate } from '../middleware/auth.js'
import { getActiveGoogleIntegration, ensureAccessToken } from '../integrations/google.store.js'
import { listReviews, updateReviewReply } from '../integrations/google.js'

const router = Router()

router.get('/', authenticate, async (req, res) => {
  const location_id = String(req.query.location_id || '')
  if (!location_id) return res.status(400).json({ error: { code: 'bad_request', message: 'location_id required' } })

  const c = await col('reviews')
  const reviews = await c.find({ user_id: req.user.user_id, location_id }).sort({ createTime: -1 }).toArray()
  res.json({ reviews })
})

router.post('/sync', authenticate, async (req, res) => {
  const { location_id } = req.body || {}
  if (!location_id) return res.status(400).json({ error: { code: 'bad_request' } })

  const locations = await col('locations')
  const loc = await locations.findOne({ id: location_id, user_id: req.user.user_id, provider: 'google' })
  if (!loc) return res.status(404).json({ error: { code: 'not_found', message: 'location not found' } })

  const integ = await getActiveGoogleIntegration(req.user.user_id)
  if (!integ) return res.status(404).json({ error: { code: 'no_integration' } })

  const { access_token } = await ensureAccessToken(integ)
  const data = await listReviews(access_token, loc.provider_account_name, loc.provider_location_name)
  const list = data.reviews || []

  const c = await col('reviews')
  let upserted = 0

  for (const r of list) {
    const doc = {
      user_id: req.user.user_id,
      location_id,
      provider: 'google',
      provider_review_name: r.name, // accounts/*/locations/*/reviews/*
      starRating: r.starRating || null,
      comment: r.comment || null,
      reviewer: r.reviewer || null,
      createTime: r.createTime || null,
      updateTime: r.updateTime || null,
      reviewReply: r.reviewReply || null,
      updated_at: new Date(),
    }

    await c.updateOne(
      { user_id: req.user.user_id, location_id, provider_review_name: r.name },
      { $set: doc, $setOnInsert: { id: crypto.randomUUID(), created_at: new Date() } },
      { upsert: true }
    )

    upserted++
  }

  res.json({ upserted })
})

router.post('/:id/reply', authenticate, async (req, res) => {
  const id = String(req.params.id || '')
  const { comment } = req.body || {}
  if (!comment) return res.status(400).json({ error: { code: 'bad_request', message: 'comment required' } })

  const c = await col('reviews')
  const review = await c.findOne({ id, user_id: req.user.user_id })
  if (!review) return res.status(404).json({ error: { code: 'not_found' } })

  const integ = await getActiveGoogleIntegration(req.user.user_id)
  if (!integ) return res.status(404).json({ error: { code: 'no_integration' } })

  const { access_token } = await ensureAccessToken(integ)
  await updateReviewReply(access_token, review.provider_review_name, comment)

  await c.updateOne(
    { id, user_id: req.user.user_id },
    { $set: { reviewReply: { comment }, updated_at: new Date() } }
  )

  res.json({ ok: true })
})

export default router
