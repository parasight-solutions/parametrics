// apps/web/src/pages/integrations/GoogleLocationsImport.jsx
import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { apiFetch } from "@/lib/api";

export default function GoogleLocationsImport() {
  const { token } = useAuth();
  const [accountName, setAccountName] = useState(""); // e.g. "accounts/12345678901234567890"
  const [result, setResult] = useState(null);
  const [err, setErr] = useState(null);

  const run = async () => {
    setErr(null); setResult(null);
    try {
      const data = await apiFetch("/api/v1/integrations/google/locations/import", {
        token,
        method: "POST",
        body: { accountName }
      });
      setResult(data);
    } catch (e) {
      setErr(e?.body?.error?.code || e.message);
    }
  };

  return (
    <div>
      <h2>Import Locations</h2>
      <input
        style={{width:'420px'}}
        placeholder='accounts/12345678901234567890'
        value={accountName}
        onChange={e=>setAccountName(e.target.value)}
      />
      <button onClick={run} disabled={!accountName}>Import</button>
      {err && <p style={{color:'crimson'}}>Error: {String(err)}</p>}
      {result && <pre>{JSON.stringify(result,null,2)}</pre>}
    </div>
  );
}
