// apps/web/src/pages/Posts.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import AppShell from "../components/AppShell";
import ActiveLocationPicker, { getActiveLocationId } from "../components/ActiveLocationPicker";
import { api } from "../apiClient";

function toLocalInputValue(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

function prettyWhen(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleString();
}

function StatusPill({ status }) {
  const s = String(status || "").toLowerCase();
  const cls =
    s === "published"
      ? "bg-green-100 text-green-700"
      : s === "failed"
      ? "bg-red-100 text-red-700"
      : s === "scheduled"
      ? "bg-blue-100 text-blue-700"
      : "bg-gray-100 text-gray-700";

  return <span className={`inline-flex px-2 py-1 rounded-md text-xs font-medium ${cls}`}>{status}</span>;
}

function compactErr(err) {
  if (!err) return "-";
  const s = String(err);
  if (s.length <= 120) return s;
  return s.slice(0, 120) + "…";
}

export default function Posts({ onLogout }) {
  const nav = useNavigate();
  const [locationId, setLocationId] = useState(getActiveLocationId());
  const [showAll, setShowAll] = useState(false);

  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);

  const [editing, setEditing] = useState(null); // post object
  const [editSummary, setEditSummary] = useState("");
  const [editMode, setEditMode] = useState("publish"); // 'publish' | 'schedule'
  const [editSchedule, setEditSchedule] = useState("");
  const [busyId, setBusyId] = useState("");

  const query = useMemo(() => {
    if (showAll) return "";
    if (!locationId) return "";
    return `?locationId=${encodeURIComponent(locationId)}`;
  }, [showAll, locationId]);

  async function load() {
    setLoading(true);
    try {
      const out = await api(`/posts${query}`);
      setPosts(out.posts || []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  function openEdit(p) {
    setEditing(p);
    setEditSummary(p.summary || "");
    if (p.status === "scheduled" && p.scheduled_at) {
      setEditMode("schedule");
      setEditSchedule(toLocalInputValue(p.scheduled_at));
    } else {
      setEditMode("publish");
      setEditSchedule("");
    }
  }

  async function saveEdit() {
    if (!editing) return;
    if (!editSummary.trim()) {
      alert("Summary is required");
      return;
    }

    const body = { summary: editSummary.trim() };

    if (editMode === "schedule") {
      if (!editSchedule) {
        alert("Pick a schedule date/time");
        return;
      }
      body.publishNow = false;
      body.scheduleAt = new Date(editSchedule).toISOString();
    } else {
      body.publishNow = true;
    }

    setBusyId(editing.id);
    try {
      await api(`/posts/${editing.id}`, { method: "PATCH", body });
      setEditing(null);
      await load();
    } finally {
      setBusyId("");
    }
  }

  async function del(p) {
    if (!confirm("Delete this post?")) return;
    setBusyId(p.id);
    try {
      await api(`/posts/${p.id}`, { method: "DELETE" });
      await load();
    } finally {
      setBusyId("");
    }
  }

  async function retry(p) {
    setBusyId(p.id);
    try {
      await api(`/posts/${p.id}/retry`, { method: "POST" });
      await load();
    } finally {
      setBusyId("");
    }
  }

  return (
    <AppShell
      title="Posts"
      subtitle="Create and publish Google Business Profile updates"
      onLogout={onLogout}
      actions={
        <div className="flex items-center gap-2">
          <button onClick={load} className="px-3 py-2 rounded-lg border bg-white text-sm hover:bg-gray-100">
            Refresh
          </button>
          <button
            onClick={() => nav("/posts/new")}
            className="px-3 py-2 rounded-lg bg-gray-900 text-white text-sm hover:bg-black"
          >
            New Post
          </button>
        </div>
      }
    >
      <div className="bg-white border rounded-xl p-5 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
          <div>
            <div className="text-sm text-gray-600 mb-2">Active Location (for filtering)</div>
            <ActiveLocationPicker value={locationId} onChange={setLocationId} />
            <label className="mt-2 flex items-center gap-2 text-sm text-gray-700">
              <input type="checkbox" checked={showAll} onChange={(e) => setShowAll(e.target.checked)} />
              Show all locations
            </label>
          </div>

          <div className="text-sm text-gray-600 md:text-right">
            {loading ? "Loading…" : `${posts.length} post(s)`}
          </div>
        </div>

        <div className="overflow-auto border rounded-xl">
          <table className="min-w-[900px] w-full text-sm">
            <thead>
              <tr className="text-left border-b bg-gray-50">
                <th className="py-3 px-3">Summary</th>
                <th className="py-3 px-3">Location</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Scheduled</th>
                <th className="py-3 px-3">Provider Ref</th>
                <th className="py-3 px-3">Error</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>

            <tbody>
              {posts.map((p) => (
                <tr key={p.id} className="border-b align-top">
                  <td className="py-3 px-3 font-medium">{p.summary}</td>

                  <td className="py-3 px-3">
                    <div className="font-medium">{p.location?.title || p.location_id}</div>
                    <div className="text-xs text-gray-500">{p.location_id}</div>
                  </td>

                  <td className="py-3 px-3">
                    <StatusPill status={p.status} />
                  </td>

                  <td className="py-3 px-3">{prettyWhen(p.scheduled_at)}</td>

                  <td className="py-3 px-3">
                    {p.provider_post_name ? (
                      <span className="text-xs break-all">{p.provider_post_name}</span>
                    ) : (
                      "-"
                    )}
                  </td>

                  <td className="py-3 px-3">
                    <span className="text-xs text-red-700 break-all">{compactErr(p.provider_error)}</span>
                  </td>

                  <td className="py-3 px-3">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => openEdit(p)}
                        disabled={busyId === p.id || p.status === "published"}
                        className="px-3 py-2 rounded-lg border bg-white text-sm hover:bg-gray-100 disabled:opacity-50"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => del(p)}
                        disabled={busyId === p.id}
                        className="px-3 py-2 rounded-lg border bg-white text-sm hover:bg-gray-100 disabled:opacity-50"
                      >
                        Delete
                      </button>
                      <button
                        onClick={() => retry(p)}
                        disabled={busyId === p.id || p.status !== "failed"}
                        className="px-3 py-2 rounded-lg border bg-white text-sm hover:bg-gray-100 disabled:opacity-50"
                      >
                        Retry
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {!posts.length && !loading ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-gray-500">
                    No posts yet.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Modal */}
      {editing ? (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-lg bg-white rounded-xl border shadow-lg p-5 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-lg font-semibold">Edit Post</div>
                <div className="text-xs text-gray-500">{editing.location?.title}</div>
              </div>
              <button onClick={() => setEditing(null)} className="text-sm px-2 py-1 rounded hover:bg-gray-100">
                ✕
              </button>
            </div>

            <label className="block text-sm">
              <div className="text-gray-700 mb-1">Text</div>
              <textarea
                value={editSummary}
                onChange={(e) => setEditSummary(e.target.value)}
                className="w-full border rounded-lg px-3 py-2"
                rows={4}
              />
            </label>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="radio"
                  name="mode"
                  checked={editMode === "publish"}
                  onChange={() => setEditMode("publish")}
                />
                Publish now
              </label>

              <label className="flex items-center gap-2 text-sm">
                <input
                  type="radio"
                  name="mode"
                  checked={editMode === "schedule"}
                  onChange={() => setEditMode("schedule")}
                />
                Schedule
              </label>

              {editMode === "schedule" ? (
                <input
                  type="datetime-local"
                  value={editSchedule}
                  onChange={(e) => setEditSchedule(e.target.value)}
                  className="w-full border rounded-lg px-3 py-2"
                />
              ) : null}
            </div>

            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setEditing(null)}
                className="px-4 py-2 rounded-lg border bg-white hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={saveEdit}
                disabled={busyId === editing.id}
                className="px-4 py-2 rounded-lg bg-gray-900 text-white hover:bg-black disabled:opacity-50"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </AppShell>
  );
}
