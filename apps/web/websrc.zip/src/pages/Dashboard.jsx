// apps/web/src/pages/Dashboard.jsx
import { useEffect, useMemo, useState } from "react";
import AppShell from "../components/AppShell";
import ActiveLocationPicker, { getActiveLocationId } from "../components/ActiveLocationPicker";
import { api } from "../apiClient";

export default function Dashboard({ onLogout }) {
  const [locationId, setLocationId] = useState(getActiveLocationId());
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!locationId) return;
    (async () => {
      setLoading(true);
      try {
        const out = await api(`/integrations/google/performance-series?locationId=${encodeURIComponent(locationId)}&days=30`);
        setData(out);
      } finally {
        setLoading(false);
      }
    })();
  }, [locationId]);

  const metrics = data?.metrics || [];
  const byName = useMemo(() => {
    const m = new Map();
    for (const x of metrics) m.set(x.metric, x);
    return m;
  }, [metrics]);

  const getTotal = (name) => byName.get(name)?.total ?? 0;
  const getPoints = (name) => byName.get(name)?.points ?? [];

  return (
    <AppShell title="Dashboard" subtitle="Google Business Profile performance (last 30 days)" onLogout={onLogout}>
      <div className="bg-white border rounded-xl p-5">
        <div className="text-sm text-gray-600 mb-2">Active Location</div>
        <ActiveLocationPicker value={locationId} onChange={setLocationId} />
      </div>

      {!locationId ? <div className="text-gray-600">Pick a location to load performance metrics.</div> : null}
      {loading ? <div className="text-gray-600">Loading performance…</div> : null}

      {data && !loading ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Kpi title="Website Clicks" value={getTotal("WEBSITE_CLICKS")} points={getPoints("WEBSITE_CLICKS")} />
            <Kpi title="Call Clicks" value={getTotal("CALL_CLICKS")} points={getPoints("CALL_CLICKS")} />
            <Kpi title="Direction Requests" value={getTotal("DIRECTIONS_REQUESTS")} points={getPoints("DIRECTIONS_REQUESTS")} />
            <Kpi title="Search Impressions" value={getTotal("BUSINESS_IMPRESSIONS_SEARCH")} points={getPoints("BUSINESS_IMPRESSIONS_SEARCH")} />
            <Kpi title="Maps Impressions" value={getTotal("BUSINESS_IMPRESSIONS_MAPS")} points={getPoints("BUSINESS_IMPRESSIONS_MAPS")} />
          </div>

          <div className="bg-white border rounded-xl p-5 overflow-auto">
            <div className="font-semibold mb-3">Raw totals</div>
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left border-b">
                  <th className="py-2 pr-4">Metric</th>
                  <th className="py-2 pr-4">Total</th>
                </tr>
              </thead>
              <tbody>
                {metrics.map((m) => (
                  <tr key={m.metric} className="border-b">
                    <td className="py-2 pr-4">{m.metric}</td>
                    <td className="py-2 pr-4">{m.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      ) : null}
    </AppShell>
  );
}

function Kpi({ title, value, points }) {
  return (
    <div className="bg-white border rounded-xl p-5 space-y-2">
      <div className="text-sm text-gray-600">{title}</div>
      <div className="text-2xl font-bold">{value}</div>
      {points?.length ? <Sparkline points={points} /> : <div className="text-xs text-gray-400">No trend data</div>}
    </div>
  );
}

function Sparkline({ points }) {
  const vals = points.map((p) => Number(p.value || 0));
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const range = max - min || 1;

  const w = 100;
  const h = 30;
  const pad = 2;
  const step = (w - pad * 2) / Math.max(1, vals.length - 1);

  const pts = vals
    .map((v, i) => {
      const x = pad + i * step;
      const y = pad + (h - pad * 2) * (1 - (v - min) / range);
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(" ");

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-8 text-gray-700">
      <polyline fill="none" stroke="currentColor" strokeWidth="2" points={pts} />
    </svg>
  );
}
