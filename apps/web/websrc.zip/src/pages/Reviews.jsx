// apps/web/src/pages/Reviews.jsx
import { useEffect, useState } from "react";
import ActiveLocationPicker, { getActiveLocationId } from "../components/ActiveLocationPicker";
import { apiFetch } from "../apiClient";

export default function Reviews() {
  const [locationId, setLocationId] = useState(getActiveLocationId());
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(false);
  const [replying, setReplying] = useState({}); // reviewName -> text

  async function load() {
    if (!locationId) return;
    setLoading(true);
    try {
      const out = await apiFetch(`/integrations/google/reviews?locationId=${encodeURIComponent(locationId)}`);
      setReviews(out.reviews || []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [locationId]);

  async function sendReply(reviewName) {
    const comment = replying[reviewName]?.trim();
    if (!comment) return;

    await apiFetch(`/integrations/google/reviews/reply`, {
      method: "PUT",
      body: JSON.stringify({ reviewName, comment }),
    });

    await load();
  }

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Reviews</h1>

      <div className="bg-white border rounded p-4 space-y-3">
        <div className="text-sm text-gray-600">Active Location</div>
        <ActiveLocationPicker value={locationId} onChange={setLocationId} />
        <button className="border rounded px-3 py-2" onClick={load} disabled={!locationId || loading}>
          Refresh
        </button>
      </div>

      {!locationId && <div className="text-gray-600">Pick a location to load reviews.</div>}
      {loading && <div className="text-gray-600">Loading reviews…</div>}

      {!loading && reviews.map((r) => (
        <div key={r.name} className="bg-white border rounded p-4 space-y-2">
          <div className="flex items-center justify-between">
            <div className="font-semibold">{r.reviewer?.displayName || "Anonymous"}</div>
            <div className="text-sm text-gray-600">{r.starRating}</div>
          </div>
          {r.comment && <div className="text-gray-800">{r.comment}</div>}
          <div className="text-xs text-gray-500">Updated: {r.updateTime}</div>

          <div className="pt-3 border-t space-y-2">
            <div className="text-sm font-semibold">Reply</div>
            <textarea
              className="border rounded w-full p-2 text-sm"
              rows={3}
              value={replying[r.name] ?? r.reviewReply?.comment ?? ""}
              onChange={(e) => setReplying((s) => ({ ...s, [r.name]: e.target.value }))}
            />
            <button
              className="bg-black text-white rounded px-3 py-2"
              onClick={() => sendReply(r.name)}
            >
              Send Reply
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
