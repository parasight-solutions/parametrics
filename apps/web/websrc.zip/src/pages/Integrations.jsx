import { useEffect, useState } from "react";
import { api, getToken } from "../apiClient";
import AppShell from "../components/AppShell";

export default function Integrations({ onLogout }) {
  // const token = useMemo(() => getToken(), []);
  const [status, setStatus] = useState({ connected: false });
  const [accounts, setAccounts] = useState([]);
  const [selectedAccount, setSelectedAccount] = useState("");
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [msg, setMsg] = useState("");
  const [mediaByLoc, setMediaByLoc] = useState({}); // locationName -> {profilePhotoUrl}

  async function loadStatusAndAccounts() {
    setMsg("");
    setLoading(true);
    try {
      const s = await api("/integrations/google/status");
      setStatus(s);

      if (s.connected) {
        const a = await api("/integrations/google/accounts");
        setAccounts(a.accounts || []);
      } else {
        setAccounts([]);
        setSelectedAccount("");
        setLocations([]);
      }
    } catch (e) {
      setMsg(e?.message || "Failed to load integration status");
    } finally {
      setLoading(false);
    }
  }

  async function connectGoogle() {
    const t = getToken();
    if (!t) {
      setMsg(
        "You are not logged in (JWT missing). Please login again, then click Connect Google."
      );
      return;
    }

    // DEV flow: /start expects ?t=JWT
    window.location.href = `/api/v1/integrations/google/start?t=${encodeURIComponent(
      t
    )}`;
  }

  async function loadLocations(accountName) {
    if (!accountName) return;
    setMsg("");
    setLoading(true);
    try {
      const r = await api(
        `/integrations/google/locations?accountName=${encodeURIComponent(
          accountName
        )}`
      );
      setLocations(r.locations || []);
    } catch (e) {
      setMsg(e?.message || "Failed to load locations");
      setLocations([]);
    } finally {
      setLoading(false);
    }
  }

  async function importLocations() {
    if (!selectedAccount) return;
    setMsg("");
    setImporting(true);
    try {
      const r = await api("/integrations/google/locations/import", {
        method: "POST",
        body: { accountName: selectedAccount },
      });
      setMsg(`Imported/updated ${r.inserted || 0} locations.`);
    } catch (e) {
      setMsg(e?.message || "Import failed");
    } finally {
      setImporting(false);
    }
  }

  async function loadMedia(locationName) {
    if (!selectedAccount || !locationName) return;
    try {
      const r = await api(
        `/integrations/google/location-media?accountName=${encodeURIComponent(
          selectedAccount
        )}&locationName=${encodeURIComponent(locationName)}`
      );
      setMediaByLoc((prev) => ({ ...prev, [locationName]: r }));
    } catch {}
  }

  useEffect(() => {
    loadStatusAndAccounts();
  }, []);
  useEffect(() => {
    if (selectedAccount) loadLocations(selectedAccount);
  }, [selectedAccount]);

  return (
    <AppShell
      title="Integrations"
      subtitle="Connect Google Business Profile to import locations and later fetch performance metrics."
      onLogout={onLogout}
      actions={
        <button
          onClick={loadStatusAndAccounts}
          className="px-3 py-2 rounded-lg border bg-white text-sm hover:bg-gray-100 disabled:opacity-60"
          disabled={loading}
        >
          Refresh
        </button>
      }
    >
      {msg ? (
        <div className="rounded-lg border bg-white p-3 text-sm">{msg}</div>
      ) : null}

      <div className="rounded-xl border bg-white p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-lg font-semibold">Google Business Profile</div>
            <div className="text-sm text-gray-600">
              OAuth scopes: <span className="font-mono">business.manage</span>
            </div>
            <div className="mt-2 text-sm">
              Status:{" "}
              {status.connected ? (
                <span className="inline-flex items-center gap-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-green-500" />
                  Connected{status.email ? ` as ${status.email}` : ""}
                </span>
              ) : (
                <span className="inline-flex items-center gap-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-gray-300" />
                  Not connected
                </span>
              )}
            </div>
          </div>

          <button
            className="px-4 py-2 rounded-lg bg-black text-white text-sm disabled:opacity-60"
            onClick={connectGoogle}
            disabled={loading}
          >
            {status.connected ? "Reconnect Google" : "Connect Google"}
          </button>
        </div>

        {status.connected ? (
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="rounded-lg border p-4">
              <div className="font-semibold mb-2">Accounts</div>

              {accounts.length ? (
                <div className="space-y-2">
                  {accounts.map((a) => (
                    <div key={a.name} className="rounded-md border p-3">
                      <div className="font-medium">
                        {a.accountName || a.name}
                      </div>
                      <div className="text-xs text-gray-600 font-mono break-all">
                        {a.name}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-2 text-xs">
                        {a.type ? (
                          <span className="px-2 py-1 rounded bg-gray-100">
                            Type: {a.type}
                          </span>
                        ) : null}
                        {a.role ? (
                          <span className="px-2 py-1 rounded bg-gray-100">
                            Role: {a.role}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-gray-600">No accounts found.</div>
              )}
            </div>

            <div className="rounded-lg border p-4">
              <div className="font-semibold mb-2">
                Locations (Business Listings)
              </div>

              <label className="text-sm text-gray-700">Select account</label>
              <select
                className="mt-1 w-full border rounded-lg px-3 py-2"
                value={selectedAccount}
                onChange={(e) => setSelectedAccount(e.target.value)}
              >
                <option value="">-- choose --</option>
                {accounts.map((a) => (
                  <option key={a.name} value={a.name}>
                    {a.accountName || a.name}
                  </option>
                ))}
              </select>

              <div className="mt-3 flex gap-2">
                <button
                  className="px-3 py-2 rounded-lg border bg-white text-sm disabled:opacity-60"
                  onClick={() => loadLocations(selectedAccount)}
                  disabled={!selectedAccount || loading}
                >
                  Load locations
                </button>
                <button
                  className="px-3 py-2 rounded-lg bg-indigo-600 text-white text-sm disabled:opacity-60"
                  onClick={importLocations}
                  disabled={!selectedAccount || importing}
                >
                  {importing ? "Importing..." : "Import locations"}
                </button>
                <a
                  href="/locations"
                  className="px-3 py-2 rounded-lg border bg-white text-sm"
                >
                  View imported
                </a>
              </div>

              <div className="mt-4 space-y-2 max-h-80 overflow-auto pr-1">
                {locations.length ? (
                  locations.map((l) => {
                    const media = mediaByLoc[l.name] || {};
                    return (
                      <div key={l.name} className="rounded-md border p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <div className="font-medium">
                              {l.title || l.name}
                            </div>
                            {l.address ? (
                              <div className="text-sm text-gray-700">
                                {l.address}
                              </div>
                            ) : null}
                          </div>
                          {media.profilePhotoUrl ? (
                            <img
                              src={media.profilePhotoUrl}
                              alt=""
                              className="h-12 w-12 rounded-lg border object-cover"
                            />
                          ) : (
                            <button
                              className="px-2 py-1 text-xs rounded border bg-white hover:bg-gray-100"
                              onClick={() => loadMedia(l.name)}
                            >
                              Load logo
                            </button>
                          )}
                        </div>

                        <div className="mt-2 text-xs text-gray-600 flex flex-wrap gap-2">
                          {l.primaryPhone ? (
                            <span className="px-2 py-1 rounded bg-gray-100">
                              {l.primaryPhone}
                            </span>
                          ) : null}
                          {l.websiteUri ? (
                            <a
                              className="px-2 py-1 rounded bg-gray-100 break-all"
                              href={l.websiteUri}
                              target="_blank"
                            >
                              Website
                            </a>
                          ) : null}
                          {l.mapsUri ? (
                            <a
                              className="px-2 py-1 rounded bg-gray-100 break-all"
                              href={l.mapsUri}
                              target="_blank"
                            >
                              Maps
                            </a>
                          ) : null}
                        </div>

                        <div className="mt-2 text-xs text-gray-500 font-mono break-all">
                          {l.name}
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-sm text-gray-600">
                    {selectedAccount
                      ? "No locations loaded yet. Click “Load locations”."
                      : "Select an account first."}
                  </div>
                )}
              </div>

              <div className="mt-3 text-xs text-gray-500">
                Note: logos/photos are via location <b>media</b> API.
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </AppShell>
  );
}
