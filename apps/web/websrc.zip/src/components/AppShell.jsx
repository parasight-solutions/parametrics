// apps/web/src/components/AppShell.jsx
import { Link, useLocation } from "react-router-dom";

const nav = [
  { to: "/", label: "Dashboard" },
  { to: "/integrations", label: "Integrations" },
  { to: "/posts", label: "Posts" },
  { to: "/reviews", label: "Reviews" },
];

export default function AppShell({ title, subtitle, onLogout, actions, children }) {
  const loc = useLocation();
  const isActive = (to) => (to === "/" ? loc.pathname === "/" : loc.pathname.startsWith(to));

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="sticky top-0 z-10 border-b bg-white">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <Link to="/" className="font-semibold tracking-tight">
              ParaMetrics
            </Link>

            <nav className="hidden md:flex items-center gap-3 text-sm">
              {nav.map((i) => (
                <Link
                  key={i.to}
                  to={i.to}
                  className={`px-3 py-2 rounded-lg ${
                    isActive(i.to) ? "bg-gray-900 text-white" : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  {i.label}
                </Link>
              ))}
              <Link to="/posts/new" className="px-3 py-2 rounded-lg border bg-white hover:bg-gray-100">
                New Post
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-2">
            {actions}
            {onLogout ? (
              <button
                onClick={onLogout}
                className="px-3 py-2 rounded-lg border bg-white text-sm hover:bg-gray-100"
              >
                Logout
              </button>
            ) : null}
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">{title}</h1>
          {subtitle ? <p className="text-sm text-gray-600 mt-1">{subtitle}</p> : null}
        </div>

        {children}
      </main>
    </div>
  );
}
