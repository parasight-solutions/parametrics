// apps/web/src/apiClient.js
const API_BASE = "/api/v1";
const TOKEN_KEY = "token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY) || "";
}

export function setToken(token) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

function redirectToLogin() {
  // avoid infinite loops
  if (window.location.pathname !== "/login") {
    window.location.href = "/login";
  }
}

export async function api(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };

  if (auth) {
    const t = getToken();
    if (!t) {
      // You’re not logged in on this origin (localhost vs 127.0.0.1 etc.)
      redirectToLogin();
      throw { code: "unauthorized", message: "JWT missing" };
    }
    headers["Authorization"] = `Bearer ${t}`;
  }

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  // If auth broke/expired/secret changed → force relogin
  if (res.status === 401) {
    clearToken();
    redirectToLogin();
    const err = await res.json().catch(() => ({}));
    throw err.error || { code: "unauthorized", status: 401 };
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw err.error || { code: "http_error", status: res.status };
  }

  return res.json().catch(() => ({}));
}

// Back-compat for your Dashboard.jsx usage
export const apiFetch = api;
